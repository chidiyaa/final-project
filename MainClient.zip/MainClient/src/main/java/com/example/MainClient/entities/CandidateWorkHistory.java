package com.example.MainClient.entities;

import java.time.LocalDate;





import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import javax.xml.bind.annotation.XmlRootElement;

import org.hibernate.validator.constraints.NotEmpty;
@XmlRootElement
@Entity
@Table(name="candidate_work_history")

//cnadidate work history entity class
public class CandidateWorkHistory {
	@Id
    @Column(name="work_id")
	

    private String workId;
    @Column(name="candidate_Id")
    @GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq")
	@SequenceGenerator(name="seq",sequenceName="seq_purchase_id",allocationSize=1)

    private String candidateId2;
    @NotEmpty(message="which_Employer Name is Mandatory")
    @Pattern(regexp="[A-Za-z]{3,15}",message="which_Employer name Sould contain 3 and max 15 letters")
    @Column(name="which_Employer")
    private String whichEmployer;
    @NotEmpty(message="contact_person Name is Mandatory")
    @Pattern(regexp="[A-Za-z]{3,15}",message="contact_person name Sould contain 3 and max 15 letters")
    @Column(name="contact_person")
    private String contactPerson;
    @NotEmpty(message="position_held is Mandatory")
    @Pattern(regexp="[A-Za-z]{3,15}",message="position_held Sould contain 3 and max 15 letters")
    @Column(name="position_held")
    private String positionHeld;
    @NotEmpty(message="company_name is Mandatory")
    @Pattern(regexp="[A-Za-z]{3,15}",message="company_name Sould contain 3 and max 15 letters")
    @Column(name="company_name")
    private String companyName;
    @Column(name="employment_from")
    private LocalDate employmentFrom;
    @Column(name="employment_to")
    private LocalDate employmentTo;
    @NotEmpty(message="reasonForLeaving is Mandatory")
    @Pattern(regexp="[A-Za-z]{3,25}",message="reasonForLeaving Sould contain 3 and max 25 letters")
    @Column(name="reason_For_Leaving")
    private String reasonForLeaving;
    @NotEmpty(message="responsibilities is Mandatory")
    @Pattern(regexp="[A-Za-z]{3,15}",message="responsibilities Sould contain 3 and max 15 letters")
    @Column(name="responsibilities")
    private String responsibilities;
    @NotEmpty(message="hr_rep_name is Mandatory")
    @Pattern(regexp="[A-Za-z]{3,15}",message="hr_rep_name Sould contain 3 and max 15 letters")
    @Column(name="hr_rep_name")
    private String hrRepName;
    @NotEmpty(message="hr_rep_contact_num is Mandatory")
    @Pattern(regexp="[0-9]{10}",message="hr_rep_contact_num Sould contain 10 numbers")
    @Column(name="hr_rep_contact_num")
    private String hrRepContactNum;
    public String getWorkId() {
        return workId;
    }
    public void setWorkId(String workId) {
        this.workId = workId;
    }
    public String getCandidateId() {
        return candidateId2;
    }
    public void setCandidateId(String candidateId2) {
        this.candidateId2 = candidateId2;
    }
    public String getWhichEmployer() {
        return whichEmployer;
    }
    public void setWhichEmployer(String whichEmployer) {
        this.whichEmployer = whichEmployer;
    }
    public String getContactPerson() {
        return contactPerson;
    }
    public void setContactPerson(String contactPerson) {
        this.contactPerson = contactPerson;
    }
    public String getPositionHeld() {
        return positionHeld;
    }
    public void setPositionHeld(String positionHeld) {
        this.positionHeld = positionHeld;
    }
    public String getCompanyName() {
        return companyName;
    }
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
    public LocalDate getEmploymentFrom() {
        return employmentFrom;
    }
    public void setEmploymentFrom(LocalDate employmentFrom) {
        this.employmentFrom = employmentFrom;
    }
    public LocalDate getEmploymentTo() {
        return employmentTo;
    }
    public void setEmploymentTo(LocalDate employmentTo) {
        this.employmentTo = employmentTo;
    }
    public String getReasonForLeaving() {
        return reasonForLeaving;
    }
    public void setReasonForLeaving(String reasonForLeaving) {
        this.reasonForLeaving = reasonForLeaving;
    }
    public String getResponsibilities() {
        return responsibilities;
    }
    public void setResponsibilities(String responsibilities) {
        this.responsibilities = responsibilities;
    }
    public String getHrRepName() {
        return hrRepName;
    }
    public void setHrRepName(String hrRepName) {
        this.hrRepName = hrRepName;
    }
    public String getHrRepContactNum() {
        return hrRepContactNum;
    }
    public void setHrRepContactNum(String hrRepContactNum) {
        this.hrRepContactNum = hrRepContactNum;
    }
    public CandidateWorkHistory(String workId, String candidateId2,
            String whichEmployer, String contactPerson, String positionHeld,
            String companyName, LocalDate employmentFrom, LocalDate employmentTo,
            String reasonForLeaving, String responsibilities, String hrRepName,
            String hrRepContactNum) {
        super();
        this.workId = workId;
        this.candidateId2 = candidateId2;
        this.whichEmployer = whichEmployer;
        this.contactPerson = contactPerson;
        this.positionHeld = positionHeld;
        this.companyName = companyName;
        this.employmentFrom = employmentFrom;
        this.employmentTo = employmentTo;
        this.reasonForLeaving = reasonForLeaving;
        this.responsibilities = responsibilities;
        this.hrRepName = hrRepName;
        this.hrRepContactNum = hrRepContactNum;
    }
    public CandidateWorkHistory() {
    }
    @Override
    public String toString() {
        return "CandidateWorkHistory [workId=" + workId + ", candidateId="
                + candidateId2+ ", whichEmployer=" + whichEmployer
                + ", contactPerson=" + contactPerson + ", positionHeld="
                + positionHeld + ", companyName=" + companyName
                + ", employmentFrom=" + employmentFrom + ", employmentTo="
                + employmentTo + ", reasonForLeaving=" + reasonForLeaving
                + ", responsibilities=" + responsibilities + ", hrRepName="
                + hrRepName + ", hrRepContactNum=" + hrRepContactNum + "]";
    }
}


