package com.example.MainClient.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.MainClient.entities.JobApplied;
import com.example.MainClient.entities.JobRequirements;
import com.example.MainClient.entities.CandidatePersonal;
import com.example.MainClient.entities.CandidateQualifications;
import com.example.MainClient.entities.CandidateWorkHistory;
import com.example.MainClient.entities.ResponseClient;
import com.example.MainClient.exception.CandidateNotFoundException;
import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;
import com.netflix.discovery.shared.Application;


@RefreshScope
@RestController

//Main Contoller class
public class MainController{
    @Autowired
    private RestTemplate restTemplate;
    @Autowired
    private EurekaClient eurekaClient;
    

    
    //retrieve candidate based on month
    @GetMapping("/actuator/infom/{month}")
    public ArrayList<String> findMonth(@PathVariable String month) {
        Application application = eurekaClient.getApplication("admin-service");
        InstanceInfo instanceInfo = application.getInstances().get(0);
        String url = "http://" + instanceInfo.getIPAddr() + ":" + instanceInfo.getPort() + "/" + "/placedmonth/" + month;
        System.out.println("URL" + url);
        ArrayList<String> placedMonth = restTemplate.getForObject(url, ArrayList.class);
       if(placedMonth.size()==0)
       {
    	   throw new CandidateNotFoundException("Candidate with month:"+month+" could not be found");
       }
        return placedMonth;
    }
    
     //retrieve candidate based on designation
    @GetMapping("/actuator/infod/{designation}")
    public ArrayList<String> findDesignation(@PathVariable String designation) {
        Application application = eurekaClient.getApplication("admin-service");
        InstanceInfo instanceInfo = application.getInstances().get(0);
        String url = "http://" + instanceInfo.getIPAddr() + ":" + instanceInfo.getPort() + "/" + "/placeddesignation/" + designation;
        System.out.println("URL" + url);
        ArrayList<String> placedDesignation = restTemplate.getForObject(url, ArrayList.class);
        if(placedDesignation.size()==0)
        {
     	   throw new CandidateNotFoundException("Candidate with designation:"+designation+" could not be found");
        }
        return placedDesignation;
    }
    
    //retrieve candidate based on company
    @GetMapping("/actuator/infoc/{company}")
    public ArrayList<String> findCompany(@PathVariable String company) {
        Application application = eurekaClient.getApplication("admin-service");
        InstanceInfo instanceInfo = application.getInstances().get(0);
        String url = "http://" + instanceInfo.getIPAddr() + ":" + instanceInfo.getPort() + "/" + "/placedcompany/" + company;
        System.out.println("URL" + url);
        ArrayList<String> placedCompany = restTemplate.getForObject(url, ArrayList.class);
        if(placedCompany.size()==0)
        {
     	   throw new CandidateNotFoundException("Candidate with company:"+company+" could not be found");
        }
        return placedCompany;
    }
    @GetMapping("/actuator/info")
    public String hello(){
    	return "This is Main Client";
    }
    
    //Retrieve all jobs
    @GetMapping("/actuator/info/allJob")
    public List<JobRequirements> allJob() {
        Application application = eurekaClient.getApplication("candidate-service");
        InstanceInfo instanceInfo = application.getInstances().get(0);
        String url = "http://" + instanceInfo.getIPAddr() + ":" + instanceInfo.getPort() + "/" + "/candidate/allJob" ;
        System.out.println("URL" + url);
        List<JobRequirements> companyRq = restTemplate.getForObject(url, List.class);
        if(companyRq.size()==0)
        {
     	   throw new CandidateNotFoundException("JobRequirementsList not found");
        }
        System.out.println("RESPONSE " + companyRq);
        return companyRq;
    }
    
    //Post job applied
    @PostMapping(value="/actuator/infoapply", consumes=MediaType.APPLICATION_JSON_VALUE)
    public String apply(@RequestBody JobApplied jobApplied)
    {        Application app=eurekaClient.getApplication("candidate-service");
        InstanceInfo instanceInfo=app.getInstances().get(0);
        String url="http://"+instanceInfo.getIPAddr()+":"+instanceInfo.getPort()+"/candidate/apply";
        String bd= restTemplate.postForObject(url,jobApplied,String.class);
        System.out.println(jobApplied);
        if(bd==null || jobApplied==null)
        {
     	   throw new CandidateNotFoundException("Job not applied");
        }
      // String res = bd.getResponse();
       return bd; 
    }
    
    //add candidate personal info
   @PostMapping(value="/actuator/infocandidatep", consumes=MediaType.APPLICATION_JSON_VALUE)
   public String insertCandidatePersonal(@RequestBody CandidatePersonal candidatePersonal)
   {        Application app=eurekaClient.getApplication("candidate-service");
       InstanceInfo instanceInfo=app.getInstances().get(0);
       String url="http://"+instanceInfo.getIPAddr()+":"+instanceInfo.getPort()+"/candidate/insertp";
       String bd= restTemplate.postForObject(url,candidatePersonal,String.class);
       System.out.println(candidatePersonal);
       if(bd==null || candidatePersonal==null )
       {
    	   throw new CandidateNotFoundException("Candidate personal details not added");
       }
     // String res = bd.getResponse();
      return bd; 
   }
  
   //add candidate qualification info
   @PostMapping(value="/actuator/infocandidateq", consumes=MediaType.APPLICATION_JSON_VALUE)
   public String insertCandidateQualifications(@RequestBody CandidateQualifications candidateQualification)
   {        Application app=eurekaClient.getApplication("candidate-service");
       InstanceInfo instanceInfo=app.getInstances().get(0);
       String url="http://"+instanceInfo.getIPAddr()+":"+instanceInfo.getPort()+"/candidate/insertq";
       String bd= restTemplate.postForObject(url,candidateQualification,String.class);
       System.out.println(candidateQualification);
       if(bd==null || candidateQualification==null )
       {
    	   throw new CandidateNotFoundException("Candidate qualification details not added");
       }
     // String res = bd.getResponse();
      return bd; 
   }
   
   //add candidate work history info
   @PostMapping(value="/actuator/infocandidatew", consumes=MediaType.APPLICATION_JSON_VALUE)
   public String insertCandidateWorkHistory(@RequestBody CandidateWorkHistory candidateWorkHistory)
   {        Application app=eurekaClient.getApplication("candidate-service");
       InstanceInfo instanceInfo=app.getInstances().get(0);
       String url="http://"+instanceInfo.getIPAddr()+":"+instanceInfo.getPort()+"/candidate/insertw";
       String bd= restTemplate.postForObject(url,candidateWorkHistory,String.class);
       System.out.println(candidateWorkHistory);
       if(bd==null || candidateWorkHistory==null )
       {
    	   throw new CandidateNotFoundException("Candidate work history details not added");
       }
     // String res = bd.getResponse();
      return bd; 
   }
   
 //modify candidate personal info
   @PostMapping(value="/actuator/infocandidatemp/{candidateId}", consumes=MediaType.APPLICATION_JSON_VALUE)
   public String modifyCandidatePersonal(@RequestBody CandidatePersonal candidatePersonal,@PathVariable("candidateId") String candidateId)
   {        Application app=eurekaClient.getApplication("candidate-service");
       InstanceInfo instanceInfo=app.getInstances().get(0);
       String url="http://"+instanceInfo.getIPAddr()+":"+instanceInfo.getPort()+"/candidate/modifyp/"+candidateId;
       String bd= restTemplate.postForObject(url,candidatePersonal,String.class);
       System.out.println(candidatePersonal);
       if(bd==null || candidatePersonal==null )
       {
    	   throw new CandidateNotFoundException("Candidate personal details not modified");
       }
     // String res = bd.getResponse();
      return bd; 
   }
   
 //modify candidate qualification info
   @PostMapping(value="/actuator/infocandidatemq/{candidateId}", consumes=MediaType.APPLICATION_JSON_VALUE)
   public String modifyCandidateQualifications(@RequestBody CandidateQualifications candidateQualification,@PathVariable("candidateId") String candidateId)
   {        Application app=eurekaClient.getApplication("candidate-service");
       InstanceInfo instanceInfo=app.getInstances().get(0);
       String url="http://"+instanceInfo.getIPAddr()+":"+instanceInfo.getPort()+"/candidate/modifyq/"+candidateId;
       String bd= restTemplate.postForObject(url,candidateQualification,String.class);
       System.out.println(candidateQualification);
       if(bd==null || candidateQualification==null )
       {
    	   throw new CandidateNotFoundException("Candidate qualification details not modified");
       }
     // String res = bd.getResponse();
      return bd; 
   }
   
 //modify candidate work history info
   @PostMapping(value="/actuator/infocandidatemw/{candidateId}", consumes=MediaType.APPLICATION_JSON_VALUE)
   public String modifyCandidateWorkHistory(@RequestBody CandidateWorkHistory candidateWorkHistory,@PathVariable("candidateId") String candidateId)
   {        Application app=eurekaClient.getApplication("candidate-service");
       InstanceInfo instanceInfo=app.getInstances().get(0);
       String url="http://"+instanceInfo.getIPAddr()+":"+instanceInfo.getPort()+"/candidate/modifyw"+candidateId;
       String bd= restTemplate.postForObject(url,candidateWorkHistory,String.class);
       System.out.println(candidateWorkHistory);
       if(bd==null || candidateWorkHistory==null )
       {
    	   throw new CandidateNotFoundException("Candidate work history details not modified");
       }
     // String res = bd.getResponse();
      return bd; 
   }
   
   //Login validation
   @GetMapping(value="/actuator/infologin/{username}/{password}")
   public String validateuser(@PathVariable("username") String username,@PathVariable("password") String password)
   {   
	   Application app=eurekaClient.getApplication("login-service");
   InstanceInfo instanceInfo=app.getInstances().get(0);
   String url="http://"+instanceInfo.getIPAddr()+":"+instanceInfo.getPort()+"/retrieve/"+username+"/"+password;
   String bd= restTemplate.getForObject(url, String.class);
   
  return bd;
	   
   }
    
}