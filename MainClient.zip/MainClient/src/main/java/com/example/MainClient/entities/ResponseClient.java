package com.example.MainClient.entities;

import java.util.ArrayList;



public class ResponseClient 
{
    private String response;

    public ResponseClient(String response) 
    {
        
        this.response = response;
    }

    public ResponseClient() {

        // TODO Auto-generated constructor stub
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

   
    
}
