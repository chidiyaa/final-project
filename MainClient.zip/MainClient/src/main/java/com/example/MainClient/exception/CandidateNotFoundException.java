package com.example.MainClient.exception;

import org.springframework.web.bind.annotation.ResponseStatus;

import org.springframework.http.HttpStatus;



@ResponseStatus(HttpStatus.NOT_FOUND)

//Exception handler class
public class CandidateNotFoundException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;
	String message;

	public CandidateNotFoundException(String message) {
		super(message);
		this.message = message;
	}
	

}
