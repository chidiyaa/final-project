package com.rms.LoginRMS.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rms.LoginRMS.bean.Login;

public interface LoginDao extends JpaRepository<Login, Integer> {

}
