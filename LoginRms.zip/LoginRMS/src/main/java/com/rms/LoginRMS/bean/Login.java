package com.rms.LoginRMS.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;


//login Entity class 
@XmlRootElement
@Entity
@Table(name="users")
public class Login {
	@Column(name="username")
	private String userName;
	@Column(name="password")
	private String password;
	@Column(name="usertype")
	private String userType;
	@Column(name="id")
	private String id;
	@Id
	@Column(name="serial_no")
	private Integer serialNo;
	
	
	
	
	
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Integer getSerialNo() {
		return serialNo;
	}

	public void setSerialNo(Integer serialNo) {
		this.serialNo = serialNo;
	}

	public Login(String userName, String password, String userType, String id,
			Integer serialNo) {
		super();
		this.userName = userName;
		this.password = password;
		this.userType = userType;
		this.id = id;
		this.serialNo = serialNo;
	}
	
	@Override
	public String toString() {
		return "User [userName=" + userName + ", password=" + password
				+ ", typeUser=" + userType + ", id=" + id + ", serialNo="
				+ serialNo + "]";
	}
	public Login() {
		// TODO Auto-generated constructor stub
	}


}
