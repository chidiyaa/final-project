package com.cg.CandidateService.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.CandidateService.Bean.JobApplied;





public interface JobAppliedDao extends JpaRepository<JobApplied, String> {

}
