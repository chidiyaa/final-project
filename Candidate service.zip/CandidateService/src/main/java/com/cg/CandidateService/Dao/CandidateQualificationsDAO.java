package com.cg.CandidateService.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.CandidateService.Bean.CandidateQualifications;



public interface CandidateQualificationsDAO extends JpaRepository <CandidateQualifications,String> {


}