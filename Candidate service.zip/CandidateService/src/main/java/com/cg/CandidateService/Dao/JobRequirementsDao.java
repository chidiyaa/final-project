package com.cg.CandidateService.Dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.CandidateService.Bean.JobRequirements;




public interface JobRequirementsDao extends JpaRepository<JobRequirements, String>{
	

}
