package com.cg.CandidateService.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.CandidateService.Bean.CandidatePersonal;



public interface CandidatePersonalDAO extends JpaRepository <CandidatePersonal,String> {


}