package com.cg.CandidateService.Service;


import java.util.List;

import com.cg.CandidateService.Bean.Candidate;
import com.cg.CandidateService.Bean.CandidatePersonal;
import com.cg.CandidateService.Bean.CandidateQualifications;
import com.cg.CandidateService.Bean.CandidateWorkHistory;
import com.cg.CandidateService.Bean.JobApplied;
import com.cg.CandidateService.Bean.JobRequirements;




public interface CandidateService {
		
		public String addResumep(CandidatePersonal p)  ;
		public String addResumeq(CandidateQualifications q)  ;
		public String addResumew(CandidateWorkHistory w)  ;
			List<JobRequirements> getJobRequirements() ;

			
					

			int applyForJob(JobApplied job);

			//ArrayList<JobRequirements> findBy(String qualificationRequired,
					//String positionRequired, int experienceRequired,
				//	String jobLocation);

		
			public String modifyResumep(CandidatePersonal e, String candidateId);
			public String modifyResumeq(CandidateQualifications e,
					String candidateId);
			public String modifyResumew(CandidateWorkHistory e,
					String candidateId);

}
