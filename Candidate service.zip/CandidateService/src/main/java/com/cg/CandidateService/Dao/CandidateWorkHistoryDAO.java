package com.cg.CandidateService.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.CandidateService.Bean.CandidateWorkHistory;



public interface CandidateWorkHistoryDAO extends JpaRepository <CandidateWorkHistory,String> {


}