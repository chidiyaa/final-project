package com.cg.CandidateService.Controller;


import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.CandidateService.Bean.CandidatePersonal;
import com.cg.CandidateService.Bean.CandidateQualifications;
import com.cg.CandidateService.Bean.CandidateWorkHistory;
import com.cg.CandidateService.Bean.JobApplied;
import com.cg.CandidateService.Bean.JobRequirements;
import com.cg.CandidateService.Service.CandidateService;




@RestController
@RequestMapping("/candidate")
public class CandidateController {
	@Autowired
	CandidateService service;
	//Logger
	Logger daoLogger=null;
	
	public CandidateController() {
		daoLogger=Logger.getLogger(CandidateController.class);
		PropertyConfigurator.configure("D:/Santhosh Padakanti/Candidate-new-master/sud-master/Project/log4j.properties");
	}
	/*@GetMapping("/find/{qual}/{pos}/{exp}/{loc}")
	public ArrayList<JobRequirements> find(@PathVariable("qual") String qualification,
			@PathVariable("pos") String position,@PathVariable("exp")  int experience,@PathVariable("loc") String location)
	{
		return service.findBy(qualification,position, experience,location);
	}*/
	
	//insertion of candidate personal information
	@PostMapping("/insertp")
	public String insert(@RequestBody CandidatePersonal p)
	{//Candidate c = new Candidate(p,q,w);
		String s=service.addResumep(p);
		daoLogger.info("Successfully inserted CandidatePersonal details");
		return s;
	}
	
	//insertion of candidate qualification information
	@PostMapping("/insertq")
	public String insert(@RequestBody CandidateQualifications q)
	{//Candidate c = new Candidate(p,q,w);
		String s=service.addResumeq(q);
		daoLogger.info("Successfully inserted CandidateQualifications");
		return s;
	}
	
	//insertion of candidate work history information
	@PostMapping("/insertw")
	public String insert(@RequestBody CandidateWorkHistory w)
	{//Candidate c = new Candidate(p,q,w);
		String s=service.addResumew(w);
		daoLogger.info("Successfully inserted CandidateWorkHistory");
		return s;
	}
	
	//modify candidate personal information
	@PostMapping("/modifyp/{cId}")
	public String modify(@PathVariable("cId") String candidateId,@RequestBody CandidatePersonal e)
	{String s=service.modifyResumep(e,candidateId);
	daoLogger.info("Successfully modified CandidatePersonal");

		return s;
	}
	
	//modify candidate qualification information
	@PostMapping("/modifyq/{cId}")
	public String modify(@PathVariable("cId") String candidateId,@RequestBody CandidateQualifications e)
	{String s=service.modifyResumeq(e,candidateId);
	daoLogger.info("Successfully modified CandidateQualifications");
		return s;
	}
	
	//modify candidate work history information
	@PostMapping("/modifyw/{cId}")
	public String modify(@PathVariable("cId") String candidateId,@RequestBody CandidateWorkHistory e)
	{String s=service.modifyResumew(e,candidateId);
	daoLogger.info("Successfully modified CandidateWorkHistory");
		return s;
	}
	
	//Apply for jobs
	@PostMapping("/apply")
	public String insert(@RequestBody JobApplied e)
	{
		service.applyForJob(e);
		daoLogger.info("Successfully applied");

		return "SUCCESS";
	}
	
	//Candidate to get list of jobs
@GetMapping("/allJob")
public List<JobRequirements> getJobRequirements(){
	daoLogger.info("Successfully retreived");

	return service.getJobRequirements();
	
	
}
}
